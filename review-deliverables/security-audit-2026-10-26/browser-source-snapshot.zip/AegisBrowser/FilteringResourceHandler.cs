using AegisBrowser.Core;
using CefSharp;
using CefSharp.Handler;

namespace AegisBrowser;

internal sealed class FilteringResourceHandler(Func<NetworkRequest, FilterDecision> filter, string? topUrl,
    Action<NetworkRequest, FilterDecision>? observe = null) : ResourceRequestHandler
{
    protected override CefReturnValue OnBeforeResourceLoad(IWebBrowser control, IBrowser browser,
        IFrame frame, IRequest request, IRequestCallback callback)
    {
        var classification = ResourceClassification.FromCefName(request.ResourceType.ToString());
        var input = new NetworkRequest(request.Url, topUrl, classification.Type,
            request.ResourceType == ResourceType.MainFrame, classification.Unknown);
        var decision = filter(input);
        observe?.Invoke(input, decision);
        // Synchronous decision; never retain a CEF request, frame or callback.
        return decision.Blocked ? CefReturnValue.Cancel : CefReturnValue.Continue;
    }
}

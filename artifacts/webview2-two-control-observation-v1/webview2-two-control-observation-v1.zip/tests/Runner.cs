using System;
using AegisBrowser.WebView2Feasibility;
using AegisBrowser.WebView2TwoControl;
Console.WriteLine("OBSERVATION=" + ObservationGateTests.Run());
Console.WriteLine("LIFECYCLE=" + await LifecycleCoordinatorTests.RunAsync());
Console.WriteLine("PROFILE=" + ProfileRootPolicyTests.Run());
Console.WriteLine("NAVIGATION=" + await NavigationLeaseTrackerTests.RunAsync());
Console.WriteLine("JOURNAL=" + await DiagnosticJournalTests.RunAsync());
Console.WriteLine("OUTCOME=" + RunOutcomeTests.Run());